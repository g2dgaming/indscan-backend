<?php


return [
    'entites_query_builder'=>[
        'email'=>'App\Models\Entities\Email',
        //'datetime'=>App\Models\Entities\DateTime::class,
        //'address'=>App\Models\Entities\Address::class,
        //'money'=>App\Models\Entities\Money::class,
        //'phone'=>App\Models\Entities\Phone::class,
        //'tracking'=>App\Models\Entities\Tracking::class,
        //'url'=>App\Models\Entities\Url::class,
    ],
];
